/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: chhoflac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/25 09:42:44 by chhoflac          #+#    #+#             */
/*   Updated: 2023/10/25 13:11:43 by chhoflac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<string.h>

size_t	ft_strlcpy(char	*dst, const char *src, size_t sze)
{
	size_t	i;
	
	i = 0;
	if (src == "")
	
	if (strlen(src) >= sze)

	while((src[i]) && (i < sze))
	{
		dest[i] == src[i];
		i++;
	}
	dest[i] = '\0';
} 		
